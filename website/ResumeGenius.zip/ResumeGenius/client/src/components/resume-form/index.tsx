import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PersonalSection } from "./personal";
import { EducationSection } from "./education";
import { ExperienceSection } from "./experience";
import { SkillsSection } from "./skills";
import type { ResumeData } from "@shared/schema";

interface ResumeFormProps {
  data: ResumeData;
  onChange: (data: ResumeData) => void;
}

export function ResumeForm({ data, onChange }: ResumeFormProps) {
  return (
    <Tabs defaultValue="personal" className="space-y-4">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="personal">Personal</TabsTrigger>
        <TabsTrigger value="education">Education</TabsTrigger>
        <TabsTrigger value="experience">Experience</TabsTrigger>
        <TabsTrigger value="skills">Skills</TabsTrigger>
      </TabsList>
      
      <TabsContent value="personal">
        <PersonalSection
          data={data.personal}
          onChange={(personal) => onChange({ ...data, personal })}
        />
      </TabsContent>
      
      <TabsContent value="education">
        <EducationSection
          education={data.education}
          onChange={(education) => onChange({ ...data, education })}
        />
      </TabsContent>
      
      <TabsContent value="experience">
        <ExperienceSection
          experience={data.experience}
          onChange={(experience) => onChange({ ...data, experience })}
        />
      </TabsContent>
      
      <TabsContent value="skills">
        <SkillsSection
          skills={data.skills}
          onChange={(skills) => onChange({ ...data, skills })}
        />
      </TabsContent>
    </Tabs>
  );
}
