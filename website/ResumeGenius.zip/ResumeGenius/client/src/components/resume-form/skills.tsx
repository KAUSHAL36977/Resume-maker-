import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { skillSchema, type Skill } from "@shared/schema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, X, Trash2 } from "lucide-react";

interface SkillsSectionProps {
  skills: Skill[];
  onChange: (skills: Skill[]) => void;
}

export function SkillsSection({ skills, onChange }: SkillsSectionProps) {
  const [editIndex, setEditIndex] = useState<number | null>(null);
  const [currentSkill, setCurrentSkill] = useState("");

  const form = useForm({
    resolver: zodResolver(skillSchema),
    defaultValues: editIndex !== null ? skills[editIndex] : {
      category: "",
      skills: [],
    },
  });

  const handleAddSkill = () => {
    if (!currentSkill.trim()) return;
    const skills = form.getValues("skills") || [];
    form.setValue("skills", [...skills, currentSkill.trim()]);
    setCurrentSkill("");
  };

  const handleRemoveSkill = (index: number) => {
    const skills = form.getValues("skills") || [];
    form.setValue("skills", skills.filter((_, i) => i !== index));
  };

  const handleSubmit = (data: Skill) => {
    const newSkills = [...skills];
    if (editIndex !== null) {
      newSkills[editIndex] = data;
    } else {
      newSkills.push(data);
    }
    onChange(newSkills);
    form.reset({ category: "", skills: [] });
    setEditIndex(null);
  };

  const handleDelete = (index: number) => {
    onChange(skills.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., Programming Languages" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="skills"
                render={() => (
                  <FormItem>
                    <FormLabel>Skills</FormLabel>
                    <div className="flex gap-2">
                      <Input
                        value={currentSkill}
                        onChange={(e) => setCurrentSkill(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            handleAddSkill();
                          }
                        }}
                        placeholder="Add a skill and press Enter"
                      />
                      <Button type="button" onClick={handleAddSkill}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {form.watch("skills")?.map((skill, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="flex items-center gap-1"
                        >
                          {skill}
                          <X
                            className="h-3 w-3 cursor-pointer"
                            onClick={() => handleRemoveSkill(index)}
                          />
                        </Badge>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit">
                <Plus className="mr-2 h-4 w-4" />
                {editIndex !== null ? "Update" : "Add"} Skill Category
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {skills.map((item, index) => (
          <Card key={index}>
            <CardContent className="pt-6">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold">{item.category}</h3>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {item.skills.map((skill, skillIndex) => (
                      <Badge key={skillIndex} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setEditIndex(index);
                      form.reset(item);
                    }}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
