import type { ResumeData } from "@shared/schema";
import { Mail, Phone, MapPin, Globe, Linkedin, Github } from "lucide-react";

interface ClassicProps {
  data: ResumeData;
}

export function Classic({ data }: ClassicProps) {
  const { personal, education, experience, skills } = data;

  return (
    <div className="max-w-[800px] mx-auto p-8 text-[#333] leading-relaxed">
      <header className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">{personal.fullName}</h1>
        <div className="flex flex-wrap justify-center gap-4 text-sm">
          {personal.email && (
            <div className="flex items-center gap-1">
              <Mail className="h-4 w-4" />
              {personal.email}
            </div>
          )}
          {personal.phone && (
            <div className="flex items-center gap-1">
              <Phone className="h-4 w-4" />
              {personal.phone}
            </div>
          )}
          {personal.location && (
            <div className="flex items-center gap-1">
              <MapPin className="h-4 w-4" />
              {personal.location}
            </div>
          )}
          {personal.website && (
            <div className="flex items-center gap-1">
              <Globe className="h-4 w-4" />
              {personal.website}
            </div>
          )}
          {personal.linkedin && (
            <div className="flex items-center gap-1">
              <Linkedin className="h-4 w-4" />
              {personal.linkedin}
            </div>
          )}
          {personal.github && (
            <div className="flex items-center gap-1">
              <Github className="h-4 w-4" />
              {personal.github}
            </div>
          )}
        </div>
      </header>

      {personal.summary && (
        <section className="mb-6">
          <h2 className="text-xl font-bold border-b-2 border-gray-300 mb-3">
            Professional Summary
          </h2>
          <p className="text-sm">{personal.summary}</p>
        </section>
      )}

      {experience.length > 0 && (
        <section className="mb-6">
          <h2 className="text-xl font-bold border-b-2 border-gray-300 mb-3">
            Work Experience
          </h2>
          <div className="space-y-4">
            {experience.map((exp, index) => (
              <div key={index}>
                <h3 className="font-bold">{exp.position}</h3>
                <div className="text-sm text-gray-600">
                  {exp.company} | {exp.startDate} - {exp.endDate || "Present"}
                </div>
                <p className="text-sm mt-1">{exp.description}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {education.length > 0 && (
        <section className="mb-6">
          <h2 className="text-xl font-bold border-b-2 border-gray-300 mb-3">
            Education
          </h2>
          <div className="space-y-4">
            {education.map((edu, index) => (
              <div key={index}>
                <h3 className="font-bold">{edu.school}</h3>
                <div className="text-sm text-gray-600">
                  {edu.degree} in {edu.fieldOfStudy} | {edu.startDate} -{" "}
                  {edu.endDate || "Present"}
                </div>
                {edu.description && (
                  <p className="text-sm mt-1">{edu.description}</p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {skills.length > 0 && (
        <section>
          <h2 className="text-xl font-bold border-b-2 border-gray-300 mb-3">
            Skills
          </h2>
          <div className="space-y-2">
            {skills.map((skillGroup, index) => (
              <div key={index}>
                <h3 className="font-bold text-sm">{skillGroup.category}</h3>
                <p className="text-sm">{skillGroup.skills.join(", ")}</p>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
