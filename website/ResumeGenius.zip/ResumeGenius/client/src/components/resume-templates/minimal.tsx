import type { ResumeData } from "@shared/schema";
import { Mail, Phone, MapPin, Globe, Linkedin, Github } from "lucide-react";

interface MinimalProps {
  data: ResumeData;
}

export function Minimal({ data }: MinimalProps) {
  const { personal, education, experience, skills } = data;

  return (
    <div className="max-w-[800px] mx-auto p-8 font-mono">
      <header className="mb-8">
        <h1 className="text-2xl font-bold mb-4">{personal.fullName}</h1>
        <div className="flex flex-wrap gap-4 text-sm">
          {personal.email && (
            <div className="flex items-center gap-1">
              <Mail className="h-3 w-3" />
              <span className="text-xs">{personal.email}</span>
            </div>
          )}
          {personal.phone && (
            <div className="flex items-center gap-1">
              <Phone className="h-3 w-3" />
              <span className="text-xs">{personal.phone}</span>
            </div>
          )}
          {personal.location && (
            <div className="flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              <span className="text-xs">{personal.location}</span>
            </div>
          )}
          {personal.website && (
            <div className="flex items-center gap-1">
              <Globe className="h-3 w-3" />
              <span className="text-xs">{personal.website}</span>
            </div>
          )}
          {personal.linkedin && (
            <div className="flex items-center gap-1">
              <Linkedin className="h-3 w-3" />
              <span className="text-xs">{personal.linkedin}</span>
            </div>
          )}
          {personal.github && (
            <div className="flex items-center gap-1">
              <Github className="h-3 w-3" />
              <span className="text-xs">{personal.github}</span>
            </div>
          )}
        </div>
      </header>

      {personal.summary && (
        <section className="mb-8">
          <h2 className="text-sm font-bold uppercase tracking-wider mb-3">
            About
          </h2>
          <p className="text-sm leading-relaxed">{personal.summary}</p>
        </section>
      )}

      {experience.length > 0 && (
        <section className="mb-8">
          <h2 className="text-sm font-bold uppercase tracking-wider mb-3">
            Experience
          </h2>
          <div className="space-y-4">
            {experience.map((exp, index) => (
              <div key={index} className="text-sm">
                <div className="flex justify-between items-baseline">
                  <h3 className="font-bold">{exp.position}</h3>
                  <span className="text-xs">
                    {exp.startDate} - {exp.endDate || "Present"}
                  </span>
                </div>
                <div className="text-xs mb-2">{exp.company}</div>
                <p className="text-xs leading-relaxed">{exp.description}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {education.length > 0 && (
        <section className="mb-8">
          <h2 className="text-sm font-bold uppercase tracking-wider mb-3">
            Education
          </h2>
          <div className="space-y-4">
            {education.map((edu, index) => (
              <div key={index} className="text-sm">
                <div className="flex justify-between items-baseline">
                  <h3 className="font-bold">{edu.school}</h3>
                  <span className="text-xs">
                    {edu.startDate} - {edu.endDate || "Present"}
                  </span>
                </div>
                <div className="text-xs">
                  {edu.degree} in {edu.fieldOfStudy}
                </div>
                {edu.description && (
                  <p className="text-xs mt-2">{edu.description}</p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {skills.length > 0 && (
        <section>
          <h2 className="text-sm font-bold uppercase tracking-wider mb-3">
            Skills
          </h2>
          <div className="space-y-3">
            {skills.map((skillGroup, index) => (
              <div key={index} className="text-sm">
                <h3 className="text-xs font-bold mb-1">{skillGroup.category}</h3>
                <p className="text-xs">{skillGroup.skills.join(" · ")}</p>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
