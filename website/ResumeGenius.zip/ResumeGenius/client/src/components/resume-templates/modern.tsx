import type { ResumeData } from "@shared/schema";
import { Mail, Phone, MapPin, Globe, Linkedin, Github } from "lucide-react";

interface ModernProps {
  data: ResumeData;
}

export function Modern({ data }: ModernProps) {
  const { personal, education, experience, skills } = data;

  return (
    <div className="max-w-[800px] mx-auto bg-white">
      <header className="bg-primary text-primary-foreground p-8">
        <h1 className="text-4xl font-bold mb-4">{personal.fullName}</h1>
        <div className="grid grid-cols-2 gap-2 text-sm">
          {personal.email && (
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4" />
              {personal.email}
            </div>
          )}
          {personal.phone && (
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4" />
              {personal.phone}
            </div>
          )}
          {personal.location && (
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              {personal.location}
            </div>
          )}
          {personal.website && (
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              {personal.website}
            </div>
          )}
          {personal.linkedin && (
            <div className="flex items-center gap-2">
              <Linkedin className="h-4 w-4" />
              {personal.linkedin}
            </div>
          )}
          {personal.github && (
            <div className="flex items-center gap-2">
              <Github className="h-4 w-4" />
              {personal.github}
            </div>
          )}
        </div>
      </header>

      <main className="p-8 grid grid-cols-3 gap-8">
        <div className="col-span-2 space-y-6">
          {personal.summary && (
            <section>
              <h2 className="text-xl font-bold text-primary mb-3">
                Professional Summary
              </h2>
              <p className="text-sm leading-relaxed">{personal.summary}</p>
            </section>
          )}

          {experience.length > 0 && (
            <section>
              <h2 className="text-xl font-bold text-primary mb-3">
                Work Experience
              </h2>
              <div className="space-y-4">
                {experience.map((exp, index) => (
                  <div key={index} className="relative pl-4 border-l-2 border-primary">
                    <h3 className="font-bold">{exp.position}</h3>
                    <div className="text-sm text-muted-foreground">
                      {exp.company} | {exp.startDate} - {exp.endDate || "Present"}
                    </div>
                    <p className="text-sm mt-2">{exp.description}</p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {education.length > 0 && (
            <section>
              <h2 className="text-xl font-bold text-primary mb-3">Education</h2>
              <div className="space-y-4">
                {education.map((edu, index) => (
                  <div key={index} className="relative pl-4 border-l-2 border-primary">
                    <h3 className="font-bold">{edu.school}</h3>
                    <div className="text-sm text-muted-foreground">
                      {edu.degree} in {edu.fieldOfStudy} | {edu.startDate} -{" "}
                      {edu.endDate || "Present"}
                    </div>
                    {edu.description && (
                      <p className="text-sm mt-2">{edu.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>

        <div className="space-y-6">
          {skills.length > 0 && (
            <section>
              <h2 className="text-xl font-bold text-primary mb-3">Skills</h2>
              <div className="space-y-4">
                {skills.map((skillGroup, index) => (
                  <div key={index}>
                    <h3 className="font-bold text-sm mb-2">
                      {skillGroup.category}
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {skillGroup.skills.map((skill, skillIndex) => (
                        <span
                          key={skillIndex}
                          className="px-2 py-1 bg-primary/10 rounded-full text-xs"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}
