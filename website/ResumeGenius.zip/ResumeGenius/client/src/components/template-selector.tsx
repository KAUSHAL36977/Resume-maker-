import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

interface TemplateSelectorProps {
  selected: string;
  onChange: (template: string) => void;
}

const templates = [
  {
    id: "classic",
    name: "Classic",
    description: "Traditional and professional design",
    preview: (
      <svg className="w-full h-32" viewBox="0 0 300 200">
        <rect width="300" height="40" fill="currentColor" opacity={0.1} />
        <rect y="50" width="200" height="10" fill="currentColor" opacity={0.1} />
        <rect y="70" width="300" height="2" fill="currentColor" opacity={0.1} />
        <rect y="82" width="300" height="8" fill="currentColor" opacity={0.1} />
        <rect y="100" width="300" height="8" fill="currentColor" opacity={0.1} />
        <rect y="118" width="200" height="8" fill="currentColor" opacity={0.1} />
      </svg>
    ),
  },
  {
    id: "modern",
    name: "Modern",
    description: "Contemporary two-column layout",
    preview: (
      <svg className="w-full h-32" viewBox="0 0 300 200">
        <rect width="300" height="60" fill="currentColor" opacity={0.1} />
        <rect x="200" y="70" width="100" height="130" fill="currentColor" opacity={0.05} />
        <rect y="70" width="190" height="10" fill="currentColor" opacity={0.1} />
        <rect y="90" width="190" height="8" fill="currentColor" opacity={0.1} />
        <rect y="108" width="190" height="8" fill="currentColor" opacity={0.1} />
      </svg>
    ),
  },
  {
    id: "minimal",
    name: "Minimal",
    description: "Clean and minimalist design",
    preview: (
      <svg className="w-full h-32" viewBox="0 0 300 200">
        <rect width="200" height="20" fill="currentColor" opacity={0.1} />
        <rect y="30" width="300" height="1" fill="currentColor" opacity={0.1} />
        <rect y="41" width="300" height="6" fill="currentColor" opacity={0.1} />
        <rect y="57" width="300" height="6" fill="currentColor" opacity={0.1} />
        <rect y="73" width="200" height="6" fill="currentColor" opacity={0.1} />
      </svg>
    ),
  },
];

export function TemplateSelector({ selected, onChange }: TemplateSelectorProps) {
  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Choose Template</h2>
      <div className="grid grid-cols-3 gap-4">
        {templates.map((template) => (
          <Card
            key={template.id}
            className={cn(
              "relative cursor-pointer transition-all hover:border-primary",
              selected === template.id && "border-primary"
            )}
            onClick={() => onChange(template.id)}
          >
            {selected === template.id && (
              <div className="absolute top-2 right-2 p-1 bg-primary rounded-full text-primary-foreground">
                <Check className="h-4 w-4" />
              </div>
            )}
            <div className="p-4">
              <div className="mb-4 text-primary">{template.preview}</div>
              <h3 className="font-medium">{template.name}</h3>
              <p className="text-sm text-muted-foreground">
                {template.description}
              </p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
