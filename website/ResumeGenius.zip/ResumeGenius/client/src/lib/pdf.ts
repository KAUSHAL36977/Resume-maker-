import type { ResumeData } from "@shared/schema";
import { PDFDocument, rgb } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";

const fetchFont = async (url: string) => {
  const response = await fetch(url);
  return await response.arrayBuffer();
};

export async function generatePDF(template: string, data: ResumeData): Promise<void> {
  // Create a new PDFDocument
  const pdfDoc = await PDFDocument.create();
  pdfDoc.registerFontkit(fontkit);

  // Fetch and embed fonts
  const fontUrl = "https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Me5Q.ttf";
  const fontBytes = await fetchFont(fontUrl);
  const font = await pdfDoc.embedFont(fontBytes);

  // Add a page
  const page = pdfDoc.addPage([595.276, 841.890]); // A4 size
  const { width, height } = page.getSize();
  
  // Set initial cursor position
  let y = height - 50;
  const margin = 50;
  const fontSize = 12;

  // Helper function to write text and update cursor position
  const writeText = (text: string, size = fontSize, bold = false) => {
    page.drawText(text, {
      x: margin,
      y,
      size,
      font,
      color: rgb(0, 0, 0),
    });
    y -= size + 10;
  };

  // Write personal information
  writeText(data.personal.fullName, 24, true);
  writeText(data.personal.email);
  writeText(data.personal.phone);
  writeText(data.personal.location);
  if (data.personal.website) writeText(data.personal.website);
  y -= 20;

  // Write summary
  if (data.personal.summary) {
    writeText("Professional Summary", 16, true);
    writeText(data.personal.summary);
    y -= 20;
  }

  // Write experience
  if (data.experience.length > 0) {
    writeText("Experience", 16, true);
    for (const exp of data.experience) {
      writeText(`${exp.position} at ${exp.company}`, 14, true);
      writeText(`${exp.startDate} - ${exp.endDate || "Present"}`);
      writeText(exp.description);
      y -= 10;
    }
    y -= 20;
  }

  // Write education
  if (data.education.length > 0) {
    writeText("Education", 16, true);
    for (const edu of data.education) {
      writeText(`${edu.degree} in ${edu.fieldOfStudy}`, 14, true);
      writeText(edu.school);
      writeText(`${edu.startDate} - ${edu.endDate || "Present"}`);
      if (edu.description) writeText(edu.description);
      y -= 10;
    }
    y -= 20;
  }

  // Write skills
  if (data.skills.length > 0) {
    writeText("Skills", 16, true);
    for (const skillGroup of data.skills) {
      writeText(skillGroup.category, 14, true);
      writeText(skillGroup.skills.join(", "));
      y -= 10;
    }
  }

  // Save the PDF
  const pdfBytes = await pdfDoc.save();
  const blob = new Blob([pdfBytes], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  
  // Create a link and trigger download
  const link = document.createElement("a");
  link.href = url;
  link.download = `${data.personal.fullName.replace(/\s+/g, "_")}_Resume.pdf`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
