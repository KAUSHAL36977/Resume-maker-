import { useState } from "react";
import { ResumeForm } from "@/components/resume-form";
import { TemplateSelector } from "@/components/template-selector";
import { Classic } from "@/components/resume-templates/classic";
import { Modern } from "@/components/resume-templates/modern";
import { Minimal } from "@/components/resume-templates/minimal";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Download, Save } from "lucide-react";
import { generatePDF } from "@/lib/pdf";
import type { ResumeData } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

const templates = {
  classic: Classic,
  modern: Modern,
  minimal: Minimal,
};

const defaultData: ResumeData = {
  personal: {
    fullName: "",
    email: "",
    phone: "",
    location: "",
    summary: "",
  },
  education: [],
  experience: [],
  skills: [],
};

export default function Builder() {
  const [template, setTemplate] = useState<keyof typeof templates>("classic");
  const [data, setData] = useState<ResumeData>(defaultData);
  const { toast } = useToast();

  const Template = templates[template];

  const handleDownload = async () => {
    try {
      await generatePDF(template, data);
      toast({
        title: "Success",
        description: "Resume downloaded successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PDF",
        variant: "destructive",
      });
    }
  };

  const handleSave = async () => {
    try {
      await apiRequest("POST", "/api/resumes", {
        template,
        data,
      });
      toast({
        title: "Success",
        description: "Resume saved successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save resume",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8">
        <div className="flex flex-col gap-8">
          <div className="flex items-center justify-between">
            <h1 className="text-4xl font-bold">Resume Builder</h1>
            <div className="flex gap-4">
              <Button onClick={handleSave}>
                <Save className="mr-2 h-4 w-4" />
                Save
              </Button>
              <Button onClick={handleDownload}>
                <Download className="mr-2 h-4 w-4" />
                Download PDF
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-8">
              <Card className="p-6">
                <TemplateSelector
                  selected={template}
                  onChange={(t) => setTemplate(t as keyof typeof templates)}
                />
              </Card>

              <ResumeForm
                data={data}
                onChange={setData}
              />
            </div>

            <div className="sticky top-8">
              <Card className="p-6 bg-white">
                <Template data={data} />
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}