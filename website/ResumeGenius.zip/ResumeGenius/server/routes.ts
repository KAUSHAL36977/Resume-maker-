import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertResumeSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express) {
  app.post("/api/resumes", async (req, res) => {
    try {
      const validatedData = insertResumeSchema.parse(req.body);
      const resume = await storage.createResume(validatedData);
      res.json(resume);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: "Invalid resume data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create resume" });
      }
    }
  });

  app.get("/api/resumes/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const resume = await storage.getResume(id);
    if (!resume) {
      res.status(404).json({ message: "Resume not found" });
      return;
    }
    res.json(resume);
  });

  app.put("/api/resumes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertResumeSchema.parse(req.body);
      const resume = await storage.updateResume(id, validatedData);
      if (!resume) {
        res.status(404).json({ message: "Resume not found" });
        return;
      }
      res.json(resume);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: "Invalid resume data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update resume" });
      }
    }
  });

  app.delete("/api/resumes/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const deleted = await storage.deleteResume(id);
    if (!deleted) {
      res.status(404).json({ message: "Resume not found" });
      return;
    }
    res.status(204).send();
  });

  return createServer(app);
}
