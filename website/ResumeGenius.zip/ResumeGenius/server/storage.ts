import { resumes, type Resume, type InsertResume } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getResume(id: number): Promise<Resume | undefined>;
  createResume(resume: InsertResume): Promise<Resume>;
  updateResume(id: number, resume: InsertResume): Promise<Resume | undefined>;
  deleteResume(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getResume(id: number): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume;
  }

  async createResume(resume: InsertResume): Promise<Resume> {
    const [created] = await db
      .insert(resumes)
      .values({
        template: resume.template,
        data: resume.data,
      })
      .returning();
    return created;
  }

  async updateResume(id: number, resume: InsertResume): Promise<Resume | undefined> {
    const [updated] = await db
      .update(resumes)
      .set({
        template: resume.template,
        data: resume.data,
      })
      .where(eq(resumes.id, id))
      .returning();
    return updated;
  }

  async deleteResume(id: number): Promise<boolean> {
    const [deleted] = await db
      .delete(resumes)
      .where(eq(resumes.id, id))
      .returning();
    return !!deleted;
  }
}

export const storage = new DatabaseStorage();