import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { type Template } from "@/lib/templates";
import { type Resume } from "@shared/schema";

interface PreviewPanelProps {
  template: Template | null;
  data: Partial<Resume>;
}

export function PreviewPanel({ template, data }: PreviewPanelProps) {
  const handleDownload = () => {
    // TODO: Implement PDF download
    window.print();
  };

  if (!template) {
    return (
      <Card className="p-6 text-center">
        <p className="text-muted-foreground">
          Select a template to preview your resume
        </p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Preview</h2>
        <Button onClick={handleDownload}>
          <Download className="mr-2 h-4 w-4" />
          Download PDF
        </Button>
      </div>

      <Card className="p-8 min-h-[800px] print:shadow-none">
        <div className="space-y-6">
          {data.fullName && (
            <h1 className="text-3xl font-bold text-center">{data.fullName}</h1>
          )}
          
          <div className="flex justify-center gap-4 text-sm text-muted-foreground">
            {data.email && <span>{data.email}</span>}
            {data.phone && <span>{data.phone}</span>}
          </div>

          {data.summary && (
            <div>
              <h2 className="text-lg font-semibold mb-2">Professional Summary</h2>
              <p className="text-muted-foreground">{data.summary}</p>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
