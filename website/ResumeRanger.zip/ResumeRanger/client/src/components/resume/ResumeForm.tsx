import React from 'react';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { insertResumeSchema, type InsertResume } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { type Template } from "@/lib/templates";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ResumeFormProps {
  template: Template | null;
  formData: Partial<InsertResume>;
  onChange: (data: Partial<InsertResume>) => void;
}

export function ResumeForm({ template, formData, onChange }: ResumeFormProps) {
  const { toast } = useToast();
  const form = useForm<InsertResume>({
    resolver: zodResolver(insertResumeSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      summary: "",
      experience: [],
      education: [],
      skills: [],
      template: "",
    },
  });

  // Update form values when template changes
  React.useEffect(() => {
    if (template) {
      form.setValue("template", template.id);
    }
  }, [template, form]);

  const mutation = useMutation({
    mutationFn: async (data: InsertResume) => {
      const res = await apiRequest("POST", "/api/resumes", data);
      const json = await res.json();
      return json;
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Resume saved successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = form.handleSubmit((data) => {
    if (!template) {
      toast({
        title: "Error",
        description: "Please select a template first",
        variant: "destructive",
      });
      return;
    }
    mutation.mutate(data);
  });

  return (
    <Form {...form}>
      <form
        onChange={() => onChange(form.getValues())}
        onSubmit={onSubmit}
        className="space-y-6"
      >
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold">Personal Information</h2>

          <FormField
            control={form.control}
            name="fullName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Full Name</FormLabel>
                <FormControl>
                  <Input placeholder="John Doe" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input placeholder="john@example.com" type="email" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Phone</FormLabel>
                <FormControl>
                  <Input placeholder="+1 (234) 567-8900" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="summary"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Professional Summary</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Write a brief summary of your professional background..."
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <Button
          type="submit"
          disabled={mutation.isPending || !template}
          className="w-full"
        >
          {mutation.isPending ? "Saving..." : "Save Resume"}
        </Button>
      </form>
    </Form>
  );
}