import { Card, CardContent } from "@/components/ui/card";
import { templates, type Template } from "@/lib/templates";
import { cn } from "@/lib/utils";

interface TemplateSelectorProps {
  selectedTemplate: Template | null;
  onSelect: (template: Template) => void;
}

export function TemplateSelector({ selectedTemplate, onSelect }: TemplateSelectorProps) {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Choose a Template</h2>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {templates.map((template) => (
          <Card
            key={template.id}
            className={cn(
              "cursor-pointer transition-all hover:border-primary",
              selectedTemplate?.id === template.id && "border-primary"
            )}
            onClick={() => onSelect(template)}
          >
            <CardContent className="p-4">
              <img
                src={template.preview}
                alt={template.name}
                className="aspect-[3/4] w-full object-cover rounded-md mb-3"
              />
              <h3 className="font-semibold">{template.name}</h3>
              <p className="text-sm text-muted-foreground">
                {template.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
