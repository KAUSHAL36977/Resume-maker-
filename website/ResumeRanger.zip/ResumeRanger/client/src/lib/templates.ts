export type Template = {
  id: string;
  name: string;
  description: string;
  preview: string;
};

export const templates: Template[] = [
  {
    id: "modern",
    name: "Modern",
    description: "Clean and professional layout with a modern touch",
    preview: "https://images.unsplash.com/photo-1507679799987-c73779587ccf",
  },
  {
    id: "classic",
    name: "Classic",
    description: "Traditional resume format that works for any industry",
    preview: "https://images.unsplash.com/photo-1484981138541-3d074aa97716",
  },
  {
    id: "creative",
    name: "Creative",
    description: "Stand out with a unique and bold design",
    preview: "https://images.unsplash.com/photo-1496180470114-6ef490f3ff22",
  },
];
