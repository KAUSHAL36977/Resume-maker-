import { ResumeForm } from "@/components/resume/ResumeForm";
import { PreviewPanel } from "@/components/resume/PreviewPanel";
import { TemplateSelector } from "@/components/resume/TemplateSelector";
import { useState } from "react";
import { type Template } from "@/lib/templates";
import { type Resume } from "@shared/schema";

export default function Home() {
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [formData, setFormData] = useState<Partial<Resume>>({});

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent">
            Resume Builder
          </h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-8">
            <TemplateSelector
              selectedTemplate={selectedTemplate}
              onSelect={setSelectedTemplate}
            />
            <ResumeForm
              template={selectedTemplate}
              onChange={setFormData}
              formData={formData}
            />
          </div>
          <div className="sticky top-8 h-fit">
            <PreviewPanel template={selectedTemplate} data={formData} />
          </div>
        </div>
      </main>
    </div>
  );
}
