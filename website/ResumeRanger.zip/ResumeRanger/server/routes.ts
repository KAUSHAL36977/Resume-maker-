import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertResumeSchema } from "@shared/schema";

export async function registerRoutes(app: Express) {
  app.get("/api/resumes", async (_req, res) => {
    const resumes = await storage.listResumes();
    res.json(resumes);
  });

  app.get("/api/resumes/:id", async (req, res) => {
    const resume = await storage.getResume(parseInt(req.params.id));
    if (!resume) {
      res.status(404).json({ message: "Resume not found" });
      return;
    }
    res.json(resume);
  });

  app.post("/api/resumes", async (req, res) => {
    try {
      const resume = insertResumeSchema.parse(req.body);
      const created = await storage.createResume(resume);
      res.status(201).json(created);
    } catch (error) {
      res.status(400).json({ message: "Invalid resume data" });
    }
  });

  return createServer(app);
}
