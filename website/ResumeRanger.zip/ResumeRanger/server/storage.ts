import { resumes, type Resume, type InsertResume } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getResume(id: number): Promise<Resume | undefined>;
  createResume(resume: InsertResume): Promise<Resume>;
  listResumes(): Promise<Resume[]>;
}

export class DatabaseStorage implements IStorage {
  async getResume(id: number): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume || undefined;
  }

  async createResume(insertResume: InsertResume): Promise<Resume> {
    const [resume] = await db
      .insert(resumes)
      .values([insertResume])
      .returning();
    return resume;
  }

  async listResumes(): Promise<Resume[]> {
    return await db.select().from(resumes);
  }
}

export const storage = new DatabaseStorage();