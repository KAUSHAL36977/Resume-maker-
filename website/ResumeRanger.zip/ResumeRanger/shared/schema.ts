import { pgTable, text, serial, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

const experienceSchema = z.object({
  company: z.string(),
  position: z.string(),
  startDate: z.string(),
  endDate: z.string(),
  description: z.string()
});

const educationSchema = z.object({
  school: z.string(),
  degree: z.string(),
  startDate: z.string(),
  endDate: z.string()
});

export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  summary: text("summary").notNull(),
  experience: jsonb("experience").notNull().$type<z.infer<typeof experienceSchema>[]>(),
  education: jsonb("education").notNull().$type<z.infer<typeof educationSchema>[]>(),
  skills: jsonb("skills").notNull().$type<string[]>(),
  template: text("template").notNull()
});

export const insertResumeSchema = createInsertSchema(resumes);
export type InsertResume = z.infer<typeof insertResumeSchema>;
export type Resume = typeof resumes.$inferSelect;
